<?php
if (!defined('ABSPATH')) {
	exit();
}

define('SG_POPUP_VERSION', '3.7.1');
define('SGPB_POPUP_PKG', SGPB_POPUP_PKG_FREE);
define('POPUP_BUILDER_BASENAME', 'popupbuilder-platinum/popup-builder.php');
